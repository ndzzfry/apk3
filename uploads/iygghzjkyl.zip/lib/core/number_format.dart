class NumberFormat {
  static String format(double n) {
    if (n.isNaN || n.isInfinite) return '0';
    if (n < 1000) return n.toStringAsFixed(0);
    if (n < 1e6) return '${(n / 1e3).toStringAsFixed(1)}K';
    if (n < 1e9) return '${(n / 1e6).toStringAsFixed(1)}M';
    if (n < 1e12) return '${(n / 1e9).toStringAsFixed(1)}B';
    if (n < 1e15) return '${(n / 1e12).toStringAsFixed(1)}T';
    return '${(n / 1e15).toStringAsFixed(1)}Q';
  }

  static String formatInt(int n) => format(n.toDouble());
}