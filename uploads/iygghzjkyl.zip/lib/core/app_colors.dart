import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF0F172A);
  static const surface = Color(0xFF1E293B);
  static const surfaceAlt = Color(0xFF334155);
  static const primary = Color(0xFF6366F1);
  static const accent = Color(0xFF06B6D4);

  static const money = Color(0xFFFBBF24);
  static const compute = Color(0xFF22D3EE);
  static const data = Color(0xFFA78BFA);
  static const security = Color(0xFF34D399);
  static const aiProgress = Color(0xFFF472B6);

  static const success = Color(0xFF16A34A);
  static const danger = Color(0xFFDC2626);
  static const warning = Color(0xFFEA580C);
  static const neutral = Color(0xFF475569);

  static const textPrimary = Color(0xFFF1F5F9);
  static const textSecondary = Color(0xFF94A3B8);
  static const textMuted = Color(0xFF64748B);
}