import 'package:flutter/material.dart';

class AppIcons {
  // Resources
  static const IconData money = Icons.attach_money_rounded;
  static const IconData compute = Icons.bolt_rounded;
  static const IconData data = Icons.bar_chart_rounded;
  static const IconData security = Icons.shield_rounded;
  static const IconData ai = Icons.psychology_rounded;
  static const IconData salary = Icons.payments_rounded;

  // Divisions
  static const IconData serverRoom = Icons.dns_rounded;
  static const IconData engineering = Icons.code_rounded;
  static const IconData securityDiv = Icons.security_rounded;
  static const IconData dataDiv = Icons.insights_rounded;
  static const IconData ops = Icons.badge_rounded;

  // Professions
  static const IconData softwareEngineer = Icons.terminal_rounded;
  static const IconData mlEngineer = Icons.memory_rounded;
  static const IconData cyberSecurity = Icons.gpp_good_rounded;
  static const IconData dataScientist = Icons.science_rounded;
  static const IconData devOps = Icons.settings_suggest_rounded;
  static const IconData manager = Icons.supervisor_account_rounded;
  static const IconData hr = Icons.assignment_ind_rounded;

  // UI
  static const IconData office = Icons.meeting_room_rounded;
  static const IconData team = Icons.groups_rounded;
  static const IconData upgrade = Icons.trending_up_rounded;
  static const IconData hire = Icons.person_add_alt_1_rounded;
  static const IconData reset = Icons.delete_forever_rounded;
  static const IconData voice = Icons.volume_up_rounded;
  static const IconData voiceOff = Icons.volume_off_rounded;
  static const IconData info = Icons.info_outline_rounded;
  static const IconData close = Icons.close_rounded;
  static const IconData check = Icons.check_circle_rounded;
  static const IconData warning = Icons.warning_amber_rounded;
  static const IconData error = Icons.error_rounded;
}