import 'dart:async';
import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import '../core/app_icons.dart';
import '../logic/dialogue_engine.dart';
import '../logic/event_system.dart';
import '../logic/game_engine.dart';
import '../logic/save_system.dart';
import '../models/employee.dart';
import '../models/game_state.dart';
import '../widgets/office_view.dart';
import '../widgets/resource_bar.dart';
import 'hire_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final state = GameState();
  late DialogueEngine dialogue;
  late GameEngine engine;
  late EventSystem events;
  Timer? _saveTimer;
  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    dialogue = DialogueEngine();
    engine = GameEngine(state, dialogue);
    events = EventSystem(state, dialogue);

    SaveSystem.load(state).then((_) {
      engine.start();
      events.start();
      _saveTimer = Timer.periodic(
        const Duration(seconds: 30),
        (_) => SaveSystem.save(state),
      );
    });
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    SaveSystem.save(state);
    engine.dispose();
    events.dispose();
    dialogue.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AnimatedBuilder(
          animation: state,
          builder: (_, __) => Column(
            children: [
              ResourceBar(state: state),
              Expanded(child: _buildTab()),
              _bottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTab() {
    switch (_tabIndex) {
      case 0:
        return Stack(
          children: [
            OfficeView(employees: state.employees, dialogue: dialogue),
            if (state.employees.isEmpty) _emptyHint(),
          ],
        );
      case 1:
        return _divisionList();
      case 2:
        return _upgradeList();
    }
    return const SizedBox();
  }

  Widget _emptyHint() => Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.black54,
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.business_rounded, size: 56, color: Colors.white54),
              SizedBox(height: 12),
              Text(
                'Belum ada tim nih!\nRekrut dulu yuk.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),
            ],
          ),
        ),
      );

  Widget _divisionList() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        ...Division.values.map((d) {
          final emps = state.employees.where((e) => e.division == d).toList();
          return Card(
            color: AppColors.surface,
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(d.icon, color: d.color, size: 28),
              title: Text(
                d.label,
                style: const TextStyle(color: AppColors.textPrimary),
              ),
              subtitle: Text(
                '${emps.length} karyawan',
                style: const TextStyle(color: AppColors.textSecondary),
              ),
              trailing: emps.isEmpty
                  ? null
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: emps
                          .take(3)
                          .map((e) => Padding(
                                padding: const EdgeInsets.only(left: 2),
                                child: Icon(
                                  e.profession.icon,
                                  size: 18,
                                  color: e.profession.color,
                                ),
                              ))
                          .toList(),
                    ),
            ),
          );
        }),
        const SizedBox(height: 12),
        Center(
          child: ElevatedButton.icon(
            onPressed: _openHire,
            icon: const Icon(AppIcons.hire),
            label: const Text('Rekrut Karyawan'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                  horizontal: 24, vertical: 14),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(AppIcons.salary,
                  size: 14, color: AppColors.money),
              const SizedBox(width: 4),
              Text(
                'Total gaji: ${state.fmt(state.totalSalary)}/detik',
                style: const TextStyle(
                    color: AppColors.textSecondary, fontSize: 12),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _upgradeList() {
    final cost = state.serverUpgradeCost();
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          color: AppColors.surface,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(AppIcons.serverRoom,
                        color: AppColors.compute),
                    const SizedBox(width: 8),
                    const Text(
                      'Server Room',
                      style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'Jumlah server: ${state.serverCount}',
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
                const SizedBox(height: 4),
                Text(
                  'Kapasitas compute: ${state.fmt(state.computeCapacity)}',
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: state.money >= cost
                        ? () => engine.upgradeServer()
                        : null,
                    icon: const Icon(AppIcons.upgrade),
                    label: Text(
                        'Upgrade (${state.fmt(cost)} money)'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Card(
          color: AppColors.surface,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(AppIcons.ai, color: AppColors.aiProgress),
                    const SizedBox(width: 8),
                    Text(
                      'AI Tier ${state.aiTier}',
                      style: const TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(
                  value: state.aiProgress / state.aiThreshold,
                  backgroundColor: AppColors.surfaceAlt,
                  color: AppColors.aiProgress,
                  minHeight: 8,
                  borderRadius: BorderRadius.circular(6),
                ),
                const SizedBox(height: 6),
                Text(
                  '${state.fmt(state.aiProgress)} / ${state.fmt(state.aiThreshold)}',
                  style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 12),
                ),
                const SizedBox(height: 8),
                Text(
                  'Total earned: ${state.fmt(state.totalEarned.toDouble())}',
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  secondary: Icon(
                    dialogue.voiceEnabled
                        ? AppIcons.voice
                        : AppIcons.voiceOff,
                    color: AppColors.textSecondary,
                  ),
                  title: const Text('Suara Karakter',
                      style: TextStyle(color: AppColors.textSecondary)),
                  value: dialogue.voiceEnabled,
                  activeColor: AppColors.accent,
                  onChanged: (v) =>
                      setState(() => dialogue.voiceEnabled = v),
                ),
              ],
            ),
          ),
        ),
        Card(
          color: AppColors.surface,
          child: ListTile(
            leading: const Icon(AppIcons.reset, color: AppColors.danger),
            title: const Text('Reset Progress',
                style: TextStyle(color: AppColors.textPrimary)),
            onTap: _confirmReset,
          ),
        ),
      ],
    );
  }

  void _confirmReset() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Reset semua progress?',
            style: TextStyle(color: AppColors.textPrimary)),
        content: const Text(
          'Tindakan ini tidak bisa dibatalkan.',
          style: TextStyle(color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              await SaveSystem.reset();
              setState(() => state.reset());
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Reset',
                style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
  }

  void _openHire() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => HireScreen(state: state, onHire: engine.hire),
      ),
    );
  }

  Widget _bottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.bg,
        border: Border(
          top: BorderSide(color: AppColors.accent.withOpacity(0.3)),
        ),
      ),
      child: BottomNavigationBar(
        currentIndex: _tabIndex,
        onTap: (i) => setState(() => _tabIndex = i),
        backgroundColor: Colors.transparent,
        selectedItemColor: AppColors.accent,
        unselectedItemColor: AppColors.textMuted,
        elevation: 0,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(AppIcons.office),
            label: 'Kantor',
          ),
          BottomNavigationBarItem(
            icon: Icon(AppIcons.team),
            label: 'Tim',
          ),
          BottomNavigationBarItem(
            icon: Icon(AppIcons.upgrade),
            label: 'Upgrade',
          ),
        ],
      ),
    );
  }
}