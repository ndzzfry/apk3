import 'dart:async';
import 'package:flutter/material.dart';

class TypewriterText extends StatefulWidget {
  final String text;
  final Duration speed;
  final TextStyle? style;

  const TypewriterText(
    this.text, {
    super.key,
    this.speed = const Duration(milliseconds: 28),
    this.style,
  });

  @override
  State<TypewriterText> createState() => _TypewriterTextState();
}

class _TypewriterTextState extends State<TypewriterText> {
  String _shown = '';
  int _idx = 0;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void didUpdateWidget(covariant TypewriterText old) {
    super.didUpdateWidget(old);
    if (old.text != widget.text) {
      _t?.cancel();
      _shown = '';
      _idx = 0;
      _start();
    }
  }

  void _start() {
    _t = Timer.periodic(widget.speed, (timer) {
      if (_idx < widget.text.length) {
        if (mounted) setState(() => _shown += widget.text[_idx++]);
      } else {
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Text(
      _shown,
      style: widget.style ??
          const TextStyle(
            color: Colors.white,
            fontSize: 13,
            height: 1.3,
          ),
    );
  }
}