import 'package:flutter/material.dart';
import '../models/employee.dart';
import '../logic/dialogue_engine.dart';
import 'character_sprite.dart';
import 'speech_bubble.dart';

class OfficeView extends StatelessWidget {
  final List<Employee> employees;
  final DialogueEngine dialogue;

  const OfficeView({
    super.key,
    required this.employees,
    required this.dialogue,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: dialogue,
      builder: (_, __) {
        return LayoutBuilder(
          builder: (ctx, constraints) {
            final positions = _gridPositions(
              employees.length,
              constraints.maxWidth,
              constraints.maxHeight,
            );

            return Stack(
              children: [
                Positioned.fill(child: CustomPaint(painter: _FloorPainter())),
                Positioned(left: 8, bottom: 20, child: _serverRack()),
                ...List.generate(employees.length, (i) {
                  final emp = employees[i];
                  final pos = positions[i];
                  final isSpeaking = dialogue.current?.speakerId == emp.id;
                  return Positioned(
                    left: pos.dx,
                    top: pos.dy,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (isSpeaking && dialogue.current != null)
                          SpeechBubble(
                            text: dialogue.current!.text,
                            mood: dialogue.current!.mood,
                            onTap: dialogue.dismiss,
                          ),
                        CharacterSprite(
                          employee: emp,
                          speaking: isSpeaking,
                        ),
                      ],
                    ),
                  );
                }),
              ],
            );
          },
        );
      },
    );
  }

  Widget _serverRack() {
    return Column(
      children: List.generate(
        3,
        (i) => Container(
          margin: const EdgeInsets.only(bottom: 4),
          width: 40,
          height: 24,
          decoration: BoxDecoration(
            color: const Color(0xFF1E293B),
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: Colors.cyan.withOpacity(0.4)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(
              3,
              (_) => Container(
                width: 4,
                height: 4,
                decoration: const BoxDecoration(
                  color: Colors.greenAccent,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Colors.greenAccent, blurRadius: 4),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Offset> _gridPositions(int count, double w, double h) {
    if (count == 0) return [];
    final cols = count <= 4 ? 2 : 3;
    final rows = (count / cols).ceil();
    final cellW = (w - 100) / cols;
    final cellH = (h - 180) / rows;
    final positions = <Offset>[];

    for (int i = 0; i < count; i++) {
      final row = i ~/ cols;
      final col = i % cols;
      final baseX = 60 + col * cellW + (row.isOdd ? 20 : 0);
      final baseY = 60 + row * cellH;
      positions.add(Offset(baseX, baseY));
    }
    return positions;
  }
}

class _FloorPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1E293B).withOpacity(0.4)
      ..strokeWidth = 1;

    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final gradPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          const Color(0xFF0F172A).withOpacity(0.0),
          const Color(0xFF0F172A).withOpacity(0.9),
        ],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), gradPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}