import 'package:flutter/material.dart';
import '../models/employee.dart';

class CharacterSprite extends StatefulWidget {
  final Employee employee;
  final bool speaking;

  const CharacterSprite({
    super.key,
    required this.employee,
    this.speaking = false,
  });

  @override
  State<CharacterSprite> createState() => _CharacterSpriteState();
}

class _CharacterSpriteState extends State<CharacterSprite>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final professionColor = widget.employee.profession.color;
    final moodColor = switch (widget.employee.mood) {
      'happy' => const Color(0xFF16A34A),
      'panic' => const Color(0xFFDC2626),
      'tired' => const Color(0xFFEA580C),
      _ => const Color(0xFF475569),
    };

    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final bounce = widget.speaking ? _ctrl.value * 6 : _ctrl.value * 2;
        return Transform.translate(
          offset: Offset(0, -bounce),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Shadow bawah
              Container(
                width: 40,
                height: 6,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              const SizedBox(height: 2),
              // Body karakter
              Container(
                width: 60,
                height: 70,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      professionColor.withOpacity(0.35),
                      professionColor.withOpacity(0.15),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: widget.speaking ? moodColor : Colors.white24,
                    width: widget.speaking ? 2.5 : 1.5,
                  ),
                  boxShadow: widget.speaking
                      ? [
                          BoxShadow(
                            color: moodColor.withOpacity(0.7),
                            blurRadius: 16,
                            spreadRadius: 2,
                          ),
                        ]
                      : [
                          BoxShadow(
                            color: professionColor.withOpacity(0.25),
                            blurRadius: 8,
                          ),
                        ],
                ),
                child: Center(
                  child: Icon(
                    widget.employee.profession.icon,
                    size: 34,
                    color: professionColor,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              // Nama
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  widget.employee.name,
                  style: const TextStyle(color: Colors.white, fontSize: 9),
                ),
              ),
              // Level badge
              Container(
                margin: const EdgeInsets.only(top: 2),
                padding:
                    const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: professionColor,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  'Lv${widget.employee.level}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}