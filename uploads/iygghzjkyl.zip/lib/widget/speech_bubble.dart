import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import 'typewriter_text.dart';

class SpeechBubble extends StatelessWidget {
  final String text;
  final String mood;
  final VoidCallback? onTap;

  const SpeechBubble({
    super.key,
    required this.text,
    this.mood = 'neutral',
    this.onTap,
  });

  Color get _moodColor => switch (mood) {
        'happy' => AppColors.success,
        'panic' => AppColors.danger,
        'tired' => AppColors.warning,
        _ => AppColors.neutral,
      };

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      key: ValueKey(text),
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutBack,
      builder: (_, scale, child) => Transform.scale(
        scale: scale,
        alignment: Alignment.bottomCenter,
        child: child,
      ),
      child: GestureDetector(
        onTap: onTap,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              constraints: const BoxConstraints(maxWidth: 220),
              decoration: BoxDecoration(
                color: _moodColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white24, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: _moodColor.withOpacity(0.5),
                    blurRadius: 12,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: TypewriterText(text),
            ),
            CustomPaint(
              size: const Size(18, 12),
              painter: _TailPainter(_moodColor),
            ),
          ],
        ),
      ),
    );
  }
}

class _TailPainter extends CustomPainter {
  final Color color;
  _TailPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _TailPainter old) => old.color != color;
}