import 'package:flutter/material.dart';
import '../core/app_colors.dart';
import '../core/app_icons.dart';
import '../models/game_state.dart';

class ResourceBar extends StatelessWidget {
  final GameState state;
  const ResourceBar({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.5),
        border: Border(
          bottom: BorderSide(color: AppColors.accent.withOpacity(0.3)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _ResItem(
            icon: AppIcons.money,
            value: state.fmt(state.money),
            color: AppColors.money,
          ),
          _ResItem(
            icon: AppIcons.compute,
            value:
                '${state.fmt(state.compute)}/${state.fmt(state.computeCapacity)}',
            color: AppColors.compute,
          ),
          _ResItem(
            icon: AppIcons.data,
            value: state.fmt(state.data),
            color: AppColors.data,
          ),
          _ResItem(
            icon: AppIcons.security,
            value: state.fmt(state.security),
            color: AppColors.security,
          ),
          _ResItem(
            icon: AppIcons.ai,
            value: state.fmt(state.aiProgress),
            color: AppColors.aiProgress,
          ),
        ],
      ),
    );
  }
}

class _ResItem extends StatelessWidget {
  final IconData icon;
  final String value;
  final Color color;

  const _ResItem({
    required this.icon,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 18, color: color),
        const SizedBox(height: 2),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}