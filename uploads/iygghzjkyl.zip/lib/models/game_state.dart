import 'package:flutter/foundation.dart';
import '../core/number_format.dart';
import 'employee.dart';

class GameState extends ChangeNotifier {
  double money = 100;
  double compute = 0;
  double computeCapacity = 50;
  double data = 0;
  double security = 50;
  double aiProgress = 0;
  int aiTier = 1;
  int serverCount = 1;
  int totalEarned = 0;

  List<Employee> employees = [];

  double hireCost(Profession p) {
    final count = employees.where((e) => e.profession == p).length;
    return p.baseCost * (1 + count * 0.5);
  }

  double serverUpgradeCost() => 200 * (1 + serverCount * 0.8);

  double get totalSalary => employees.fold(0.0, (s, e) => s + e.salary);

  String fmt(double n) => NumberFormat.format(n);

  double get aiThreshold => aiTier * 1000.0;

  Map<String, dynamic> toJson() => {
        'money': money,
        'compute': compute,
        'computeCapacity': computeCapacity,
        'data': data,
        'security': security,
        'aiProgress': aiProgress,
        'aiTier': aiTier,
        'serverCount': serverCount,
        'totalEarned': totalEarned,
        'employees': employees.map((e) => e.toJson()).toList(),
        'savedAt': DateTime.now().millisecondsSinceEpoch,
      };

  void applyJson(Map<String, dynamic> data_) {
    money = (data_['money'] as num).toDouble();
    compute = (data_['compute'] as num).toDouble();
    computeCapacity = (data_['computeCapacity'] as num).toDouble();
    data = (data_['data'] as num).toDouble();
    security = (data_['security'] as num).toDouble();
    aiProgress = (data_['aiProgress'] as num).toDouble();
    aiTier = data_['aiTier'] as int;
    serverCount = data_['serverCount'] as int;
    totalEarned = data_['totalEarned'] as int;
    employees = (data_['employees'] as List)
        .map((e) => Employee.fromJson(e as Map<String, dynamic>))
        .toList();
    notifyListeners();
  }

  void reset() {
    money = 100;
    compute = 0;
    computeCapacity = 50;
    data = 0;
    security = 50;
    aiProgress = 0;
    aiTier = 1;
    serverCount = 1;
    totalEarned = 0;
    employees.clear();
    notifyListeners();
  }
}