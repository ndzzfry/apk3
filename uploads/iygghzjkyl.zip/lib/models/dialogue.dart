class DialogueLine {
  final String speakerId;
  final String speakerName;
  final String text;
  final String mood;
  final Duration duration;

  DialogueLine({
    required this.speakerId,
    required this.speakerName,
    required this.text,
    this.mood = 'neutral',
    this.duration = const Duration(seconds: 4),
  });
}

enum EventType {
  serverOverload,
  hireSuccess,
  lowMorale,
  hacked,
  aiTierUp,
  randomChat,
  serverUpgrade,
}