import 'package:flutter/material.dart';
import '../core/app_icons.dart';

enum Profession {
  softwareEngineer,
  mlEngineer,
  cyberSecurity,
  dataScientist,
  devOps,
  manager,
  hr,
}

enum Division { server, engineering, security, data, ops }

enum ResourceType { money, compute, data, security, aiProgress, morale }

extension ProfessionExt on Profession {
  String get label => switch (this) {
        Profession.softwareEngineer => 'Software Engineer',
        Profession.mlEngineer => 'ML Engineer',
        Profession.cyberSecurity => 'Cyber Security',
        Profession.dataScientist => 'Data Scientist',
        Profession.devOps => 'DevOps Engineer',
        Profession.manager => 'Manager',
        Profession.hr => 'HR Specialist',
      };

  String get shortLabel => switch (this) {
        Profession.softwareEngineer => 'SWE',
        Profession.mlEngineer => 'MLE',
        Profession.cyberSecurity => 'SEC',
        Profession.dataScientist => 'DS',
        Profession.devOps => 'OPS',
        Profession.manager => 'MGR',
        Profession.hr => 'HR',
      };

  IconData get icon => switch (this) {
        Profession.softwareEngineer => AppIcons.softwareEngineer,
        Profession.mlEngineer => AppIcons.mlEngineer,
        Profession.cyberSecurity => AppIcons.cyberSecurity,
        Profession.dataScientist => AppIcons.dataScientist,
        Profession.devOps => AppIcons.devOps,
        Profession.manager => AppIcons.manager,
        Profession.hr => AppIcons.hr,
      };

  Color get color => switch (this) {
        Profession.softwareEngineer => const Color(0xFF60A5FA),
        Profession.mlEngineer => const Color(0xFFA78BFA),
        Profession.cyberSecurity => const Color(0xFF34D399),
        Profession.dataScientist => const Color(0xFFF472B6),
        Profession.devOps => const Color(0xFF22D3EE),
        Profession.manager => const Color(0xFFFBBF24),
        Profession.hr => const Color(0xFFFB923C),
      };

  Division get defaultDivision => switch (this) {
        Profession.softwareEngineer => Division.engineering,
        Profession.mlEngineer => Division.engineering,
        Profession.cyberSecurity => Division.security,
        Profession.dataScientist => Division.data,
        Profession.devOps => Division.server,
        Profession.manager => Division.ops,
        Profession.hr => Division.ops,
      };

  double get baseCost => switch (this) {
        Profession.softwareEngineer => 100,
        Profession.mlEngineer => 300,
        Profession.cyberSecurity => 250,
        Profession.dataScientist => 200,
        Profession.devOps => 150,
        Profession.manager => 400,
        Profession.hr => 180,
      };

  String get description => switch (this) {
        Profession.softwareEngineer =>
          '+0.5 AI/s, +0.2 Money/s. Membangun kode AI.',
        Profession.mlEngineer =>
          '+1.0 AI/s tapi -0.2 Compute/s. Melatih model AI.',
        Profession.cyberSecurity =>
          '+0.8 Security/s. Menjaga firewall.',
        Profession.dataScientist =>
          '+0.6 Data/s. Membersihkan dataset.',
        Profession.devOps =>
          '+0.5 Compute/s. Merawat server.',
        Profession.manager =>
          '+Morale tim. Meningkatkan semangat.',
        Profession.hr =>
          '+0.3 Money/s. Merekrut & administrasi.',
      };
}

extension DivisionExt on Division {
  String get label => switch (this) {
        Division.server => 'Server Room',
        Division.engineering => 'Engineering',
        Division.security => 'Security',
        Division.data => 'Data Lab',
        Division.ops => 'Operations',
      };

  IconData get icon => switch (this) {
        Division.server => AppIcons.serverRoom,
        Division.engineering => AppIcons.engineering,
        Division.security => AppIcons.securityDiv,
        Division.data => AppIcons.dataDiv,
        Division.ops => AppIcons.ops,
      };

  Color get color => switch (this) {
        Division.server => const Color(0xFF22D3EE),
        Division.engineering => const Color(0xFF60A5FA),
        Division.security => const Color(0xFF34D399),
        Division.data => const Color(0xFFF472B6),
        Division.ops => const Color(0xFFFBBF24),
      };
}

class Employee {
  final String id;
  final String name;
  final Profession profession;
  Division division;
  int level;
  double morale;
  double energy;
  int salary;

  Employee({
    required this.id,
    required this.name,
    required this.profession,
    required this.division,
    this.level = 1,
    this.morale = 1.0,
    this.energy = 1.0,
    int? salary,
  }) : salary = salary ?? (profession.baseCost * 0.02).round();

  Map<ResourceType, double> get production {
    final base = _baseProduction[profession] ?? {};
    final multiplier = level * morale * energy;
    return base.map((k, v) => MapEntry(k, v * multiplier));
  }

  String get mood {
    if (morale > 0.7) return 'happy';
    if (morale > 0.4) return 'neutral';
    if (morale > 0.2) return 'tired';
    return 'panic';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'profession': profession.index,
        'division': division.index,
        'level': level,
        'morale': morale,
        'energy': energy,
        'salary': salary,
      };

  factory Employee.fromJson(Map<String, dynamic> json) => Employee(
        id: json['id'] as String,
        name: json['name'] as String,
        profession: Profession.values[json['profession'] as int],
        division: Division.values[json['division'] as int],
        level: json['level'] as int,
        morale: (json['morale'] as num).toDouble(),
        energy: (json['energy'] as num).toDouble(),
        salary: json['salary'] as int,
      );
}

const _baseProduction = {
  Profession.softwareEngineer: {
    ResourceType.aiProgress: 0.5,
    ResourceType.money: 0.2,
  },
  Profession.mlEngineer: {
    ResourceType.aiProgress: 1.0,
    ResourceType.compute: -0.2,
  },
  Profession.cyberSecurity: {ResourceType.security: 0.8},
  Profession.dataScientist: {ResourceType.data: 0.6},
  Profession.devOps: {ResourceType.compute: 0.5},
  Profession.manager: {
    ResourceType.morale: 0.1,
    ResourceType.money: 0.1,
  },
  Profession.hr: {ResourceType.money: 0.3},
};