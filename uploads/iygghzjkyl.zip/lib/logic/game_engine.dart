import 'dart:async';
import 'dart:math';
import '../models/employee.dart';
import '../models/game_state.dart';
import '../models/dialogue.dart';
import 'dialogue_engine.dart';

class GameEngine {
  final GameState state;
  final DialogueEngine dialogue;
  Timer? _ticker;
  final Random _rng = Random();

  GameEngine(this.state, this.dialogue);

  void start() {
    _ticker?.cancel();
    _ticker =
        Timer.periodic(const Duration(milliseconds: 500), (_) => tick());
  }

  void tick() {
    double moneyGain = 0;
    double computeGain = 0;
    double dataGain = 0;
    double secGain = 0;
    double aiGain = 0;

    final hasManager =
        state.employees.any((e) => e.profession == Profession.manager);

    for (final emp in state.employees) {
      final prod = emp.production;
      moneyGain += prod[ResourceType.money] ?? 0;
      computeGain += prod[ResourceType.compute] ?? 0;
      dataGain += prod[ResourceType.data] ?? 0;
      secGain += prod[ResourceType.security] ?? 0;
      aiGain += prod[ResourceType.aiProgress] ?? 0;

      emp.energy = (emp.energy - 0.002).clamp(0.0, 1.0);
      if (hasManager) {
        emp.morale = (emp.morale + 0.002).clamp(0.0, 1.0);
      } else {
        emp.morale = (emp.morale - 0.001).clamp(0.0, 1.0);
      }
    }

    if (state.compute + computeGain > state.computeCapacity) {
      computeGain = state.computeCapacity - state.compute;
    }

    final salaryCost = state.totalSalary * 0.5;

    state.money += (moneyGain * 0.5) - salaryCost;
    state.compute = (state.compute + computeGain * 0.5)
        .clamp(0.0, state.computeCapacity);
    state.data += dataGain * 0.5;
    state.security = (state.security + secGain * 0.5).clamp(0.0, 100);

    if (state.money < 0) state.money = 0;
    if (moneyGain > 0) state.totalEarned += (moneyGain * 0.5).round();

    if (state.compute > 5) {
      state.aiProgress += aiGain * 0.5;
    }

    if (state.aiProgress >= state.aiThreshold) {
      state.aiProgress -= state.aiThreshold;
      state.aiTier++;
      final emp = _randomEmployee();
      if (emp != null) {
        dialogue.trigger(EventType.aiTierUp,
            employee: emp, extra: '${state.aiTier}');
      }
    }

    if (state.employees.isEmpty) state.money += 1;

    state.notifyListeners();
  }

  Employee? _randomEmployee() {
    if (state.employees.isEmpty) return null;
    return state.employees[_rng.nextInt(state.employees.length)];
  }

  void hire(Profession p, {String? customName}) {
    final cost = state.hireCost(p);
    if (state.money < cost) return;
    state.money -= cost;

    final name = customName ?? _randomNames[_rng.nextInt(_randomNames.length)];
    final emp = Employee(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      profession: p,
      division: p.defaultDivision,
    );
    state.employees.add(emp);
    dialogue.trigger(EventType.hireSuccess, employee: emp);
    state.notifyListeners();
  }

  void upgradeServer() {
    final cost = state.serverUpgradeCost();
    if (state.money < cost) return;
    state.money -= cost;
    state.serverCount++;
    state.computeCapacity += 50;
    final emp = _randomEmployee();
    if (emp != null) {
      dialogue.trigger(EventType.serverUpgrade, employee: emp);
    }
    state.notifyListeners();
  }

  void dispose() => _ticker?.cancel();

  static const _randomNames = [
    'Budi.exe', 'Siti.ai', 'Andi.dev', 'Rina.py', 'Joko.js',
    'Maya.ml', 'Dewi.db', 'Agus.sh', 'Putri.go', 'Bayu.rs',
    'Lina.cv', 'Rudi.api', 'Nina.git', 'Fajar.bot', 'Tari.ai',
    'Adi.kt', 'Sari.ts', 'Bima.io', 'Citra.hx', 'Dian.rb',
  ];
}