import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/game_state.dart';

class SaveSystem {
  static const _key = 'ai_startup_save_v1';

  static Future<void> save(GameState s) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(s.toJson()));
  }

  static Future<void> load(GameState s) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return;
    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      s.applyJson(data);

      final savedAt = data['savedAt'] as int?;
      if (savedAt != null) {
        final elapsed = DateTime.now()
            .difference(DateTime.fromMillisecondsSinceEpoch(savedAt))
            .inSeconds
            .clamp(0, 7200);
        if (elapsed > 10 && s.employees.isNotEmpty) {
          s.money += elapsed * 0.5;
          s.notifyListeners();
        }
      }
    } catch (_) {}
  }

  static Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}