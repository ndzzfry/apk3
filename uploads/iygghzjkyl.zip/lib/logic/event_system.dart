import 'dart:async';
import 'dart:math';
import '../models/employee.dart';
import '../models/game_state.dart';
import '../models/dialogue.dart';
import 'dialogue_engine.dart';

class EventSystem {
  final GameState state;
  final DialogueEngine dialogue;
  Timer? _timer;
  final Random _rng = Random();
  DateTime _lastRandomChat = DateTime.now();

  EventSystem(this.state, this.dialogue);

  void start() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _tick());
  }

  void _tick() {
    if (state.employees.isEmpty) return;

    if (DateTime.now().difference(_lastRandomChat).inSeconds > 25 &&
        _rng.nextDouble() < 0.4) {
      _lastRandomChat = DateTime.now();
      final emp = state.employees[_rng.nextInt(state.employees.length)];
      dialogue.trigger(EventType.randomChat, employee: emp);
    }

    if (state.compute >= state.computeCapacity * 0.95 &&
        _rng.nextDouble() < 0.3) {
      final emp = _pickEmployee(Profession.devOps) ??
          _pickEmployee(Profession.mlEngineer) ??
          state.employees.first;
      dialogue.trigger(EventType.serverOverload, employee: emp);
    }

    final lowMorale = state.employees.where((e) => e.morale < 0.3).toList();
    if (lowMorale.isNotEmpty && _rng.nextDouble() < 0.25) {
      dialogue.trigger(EventType.lowMorale,
          employee: lowMorale[_rng.nextInt(lowMorale.length)]);
    }

    if (state.security < 20 && _rng.nextDouble() < 0.15) {
      final emp = _pickEmployee(Profession.cyberSecurity) ??
          state.employees.first;
      final stolen = state.money * 0.1;
      state.money -= stolen;
      state.notifyListeners();
      dialogue.trigger(EventType.hacked, employee: emp);
    }
  }

  Employee? _pickEmployee(Profession p) {
    final list = state.employees.where((e) => e.profession == p).toList();
    return list.isEmpty ? null : list[_rng.nextInt(list.length)];
  }

  void dispose() => _timer?.cancel();
}