import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../models/dialogue.dart';
import '../models/employee.dart';

class DialogueEngine extends ChangeNotifier {
  final List<DialogueLine> _queue = [];
  DialogueLine? current;
  Timer? _autoHideTimer;
  final Random _rng = Random();
  final FlutterTts _tts = FlutterTts();
  bool voiceEnabled = true;
  bool _ttsReady = false;

  DialogueEngine() {
    _initTts();
  }

  Future<void> _initTts() async {
    try {
      await _tts.setLanguage('id-ID');
      await _tts.setPitch(1.1);
      await _tts.setSpeechRate(0.5);
      await _tts.setVolume(1.0);
      _ttsReady = true;
    } catch (_) {
      _ttsReady = false;
    }
  }

  void trigger(EventType event, {Employee? employee, String? extra}) {
    final line = _pickLine(event, employee, extra);
    if (line == null) return;
    _queue.add(line);
    if (current == null) _showNext();
  }

  DialogueLine? _pickLine(EventType event, Employee? emp, String? extra) {
    final name = emp?.name ?? 'Tim';
    final id = emp?.id ?? 'system';

    switch (event) {
      case EventType.serverOverload:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'Boss! Server kita overheating!',
            'Compute kita hampir penuh, butuh upgrade!',
            'Suhu server udah 90 derajat, gimana ini?',
          ]),
          mood: 'panic',
        );
      case EventType.hireSuccess:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'Hai! Aku $name, siap kerja!',
            'Senang bergabung, Boss!',
            'Wah kantornya keren juga ya!',
          ]),
          mood: 'happy',
        );
      case EventType.lowMorale:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'Aku capek banget... boleh cuti gak?',
            'Gaji segini gak cukup buat kopi harian.',
            'Boss, tim kita butuh manager nih...',
          ]),
          mood: 'tired',
        );
      case EventType.hacked:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'BAHAYA! Ada yang bobol firewall kita!',
            'Kita kena hack! Uang hilang!',
            'Security kita lemah banget, Boss!',
          ]),
          mood: 'panic',
        );
      case EventType.aiTierUp:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'AI kita naik level! Tier ${extra ?? "baru"}!',
            'Kita berhasil! Model makin pinter!',
            'Breakthrough! AI kita makin canggih!',
          ]),
          mood: 'happy',
        );
      case EventType.serverUpgrade:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'Server baru udah nyala!',
            'Compute capacity naik nih!',
            'Mantap, server upgrade berhasil!',
          ]),
          mood: 'happy',
        );
      case EventType.randomChat:
        return DialogueLine(
          speakerId: id,
          speakerName: name,
          text: _pick([
            'Boss, kopi di pantry habis nih...',
            'Eh, kita udah punya berapa server ya?',
            'Kucing kantor lewat lagi tuh.',
            'AI kita makin pinter ya, serem...',
            'Btw, gaji bulan ini cair kapan?',
            'Aku mimpi jadi AGI semalam.',
          ]),
          mood: emp?.mood ?? 'neutral',
        );
    }
  }

  String _pick(List<String> list) => list[_rng.nextInt(list.length)];

  void _showNext() {
    _autoHideTimer?.cancel();
    if (_queue.isEmpty) {
      current = null;
      notifyListeners();
      return;
    }
    current = _queue.removeAt(0);
    notifyListeners();

    if (voiceEnabled && _ttsReady && current != null) {
      _tts.stop();
      _tts.speak(current!.text);
    }

    _autoHideTimer = Timer(current!.duration, () {
      current = null;
      notifyListeners();
      Future.delayed(const Duration(milliseconds: 300), _showNext);
    });
  }

  void dismiss() {
    _autoHideTimer?.cancel();
    current = null;
    notifyListeners();
    _showNext();
  }

  @override
  void dispose() {
    _autoHideTimer?.cancel();
    _tts.stop();
    super.dispose();
  }
}