/* ============================================================
   SISTEM LOGIN — HANYA 1 AKUN: NdizzXD / NdizzXD270
   ============================================================ */
const VALID_USER = 'NdizzXD';
const VALID_PASS = 'NdizzXD270';

let currentUser = null;

/* ---------- Toggle Password ---------- */
function toggleLoginPassword(){
  const passInput = document.getElementById('loginPassword');
  const icon = document.getElementById('togglePass');
  if(passInput.type === 'password'){
    passInput.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    passInput.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}

/* ---------- Login Handler ---------- */
document.getElementById('btnLogin').addEventListener('click', function(){
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value.trim();
  const errorDiv = document.getElementById('loginError');

  if(!username || !password){
    errorDiv.innerText = 'Username & Password wajib diisi!';
    errorDiv.style.display = 'block';
    return;
  }

  if(username === VALID_USER && password === VALID_PASS){
    currentUser = { username: VALID_USER, password: VALID_PASS, role: 'Owner', expired: 'Lifetime' };
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    errorDiv.style.display = 'none';

    document.getElementById('loginWrapper').classList.add('hide');
    document.getElementById('dashboardWrapper').classList.add('show');
    updateDashboardWithUser();
    showSimplePopup('Selamat datang, ' + username + '!');
  } else {
    errorDiv.innerText = 'Username atau Password salah!';
    errorDiv.style.display = 'block';
  }
});

/* ---------- Update Dashboard ---------- */
function updateDashboardWithUser(){
  if(!currentUser) return;
  document.getElementById('homeUsername').innerText = currentUser.username;
  document.getElementById('homeRole').innerText = currentUser.role;
  document.getElementById('homeExpired').innerText = currentUser.expired;
  document.getElementById('attackUsername').innerText = currentUser.username;
  document.getElementById('attackRole').innerText = 'ROLE : ' + currentUser.role;
  document.getElementById('attackExpired').innerText = 'EXPIRED : ' + currentUser.expired;
  document.getElementById('sbUser').innerText = currentUser.username;
  document.getElementById('sbRole').innerText = currentUser.role;
}

/* ---------- Navigation ---------- */
function goToPage(pageId){
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  const navMap = { 'home':'nav-home', 'attack':'nav-wa', 'tutorial-badak':'nav-tutor' };
  if(navMap[pageId] && document.getElementById(navMap[pageId])){
    document.getElementById(navMap[pageId]).classList.add('active');
  }
  const sidebar = document.getElementById('sidebarMenu');
  const overlay = document.getElementById('sidebarOverlay');
  if(sidebar) sidebar.classList.remove('active');
  if(overlay) overlay.classList.remove('active');

  const currentActive = document.querySelector('.page-container.active');
  const target = document.getElementById('page-' + pageId);

  const showTarget = () => {
    if(!target) return;
    target.style.display = 'block';
    setTimeout(() => {
      target.classList.add('active');
      target.classList.add('show');
      window.scrollTo(0,0);
    }, 10);
  };

  if(currentActive){
    currentActive.classList.remove('show');
    setTimeout(() => {
      currentActive.classList.remove('active');
      currentActive.style.display = 'none';
      showTarget();
    }, 400);
  } else {
    showTarget();
  }
}

/* ---------- Sidebar ---------- */
function toggleSidebar(){
  const sidebar = document.getElementById('sidebarMenu');
  const overlay = document.getElementById('sidebarOverlay');
  if(sidebar) sidebar.classList.toggle('active');
  if(overlay) overlay.classList.toggle('active');
}

/* ---------- Popup Simple ---------- */
function showSimplePopup(msg){
  const popup = document.getElementById('simplePopup');
  if(popup){
    popup.innerHTML = '<i class="fas fa-info-circle"></i> ' + msg;
    popup.classList.add('show');
    setTimeout(() => popup.classList.remove('show'), 3000);
  }
}

/* ---------- Logout ---------- */
function openLogoutPopup(){
  document.getElementById('sidebarMenu').classList.remove('active');
  document.getElementById('sidebarOverlay').classList.remove('active');
  document.getElementById('logoutModal').style.display = 'flex';
}
function closeLogoutPopup(){
  document.getElementById('logoutModal').style.display = 'none';
}
function executeLogout(){
  currentUser = null;
  localStorage.removeItem('currentUser');
  closeLogoutPopup();
  showSimplePopup('Logout Berhasil!');
  setTimeout(() => {
    document.getElementById('loginWrapper').classList.remove('hide');
    document.getElementById('dashboardWrapper').classList.remove('show');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
  }, 800);
}

/* ---------- Dropdown Badak ---------- */
function toggleBugDropdown(){
  const dropdownList = document.getElementById('bugList');
  const ddIcon = document.getElementById('ddIcon');
  const isActive = dropdownList.classList.contains('active');
  if(isActive){
    dropdownList.classList.remove('active');
    if(ddIcon) ddIcon.style.transform = 'rotate(0deg)';
  } else {
    dropdownList.classList.add('active');
    if(ddIcon) ddIcon.style.transform = 'rotate(180deg)';
  }
}
function selectBug(name, val, index){
  const btnTextSpan = document.querySelector('#bugBtnText span');
  const bugInput = document.getElementById('bugValue');
  if(btnTextSpan) btnTextSpan.innerText = name;
  if(bugInput) bugInput.value = val;
  document.getElementById('bugList').classList.remove('active');
  const ddIcon = document.getElementById('ddIcon');
  if(ddIcon) ddIcon.style.transform = 'rotate(0deg)';
}
window.addEventListener('click', function(e){
  const dropdown = document.getElementById('bugDropdown');
  if(dropdown && !dropdown.contains(e.target)){
    const dropdownList = document.getElementById('bugList');
    const ddIcon = document.getElementById('ddIcon');
    if(dropdownList) dropdownList.classList.remove('active');
    if(ddIcon) ddIcon.style.transform = 'rotate(0deg)';
  }
});

/* ---------- Attack Handler ---------- */
const sendBtn = document.getElementById('btnSendAttack');
const resultModal = document.getElementById('attackModal');

if(sendBtn){
  sendBtn.addEventListener('click', () => {
    const target = document.getElementById('targetNum').value.trim();
    const bug = document.getElementById('bugValue').value;
    const methodText = document.querySelector('#bugBtnText span')
      ? document.querySelector('#bugBtnText span').innerText : bug;

    if(!target) return showSimplePopup('Masukkan Nomor Target!');
    if(!bug) return showSimplePopup('Pilih Metode Badak Dulu!');

    const lastAttack = localStorage.getItem('lastAttackTime');
    const now = Date.now();
    const cooldownTime = 3 * 60 * 1000;

    if(lastAttack && (now - lastAttack < cooldownTime)){
      const sisa = Math.ceil((cooldownTime - (now - lastAttack)) / 1000);
      return showSimplePopup('Cooldown: Tunggu ' + sisa + ' detik!');
    }

    const originalText = sendBtn.innerHTML;
    sendBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Loading...';
    sendBtn.disabled = true;

    setTimeout(() => {
      sendBtn.innerHTML = originalText;
      sendBtn.disabled = false;

      const dateNow = new Date().toLocaleString();
      document.getElementById('resMethod').innerText = methodText;
      document.getElementById('resDate').innerText = dateNow;
      document.getElementById('resTarget').innerText = target;

      const overlay = document.getElementById('overlay');
      if(overlay) overlay.classList.add('active');
      if(resultModal) resultModal.classList.add('active');

      let percent = 0;
      const bar = document.getElementById('attackProgress');
      const txt = document.getElementById('statusPercent');
      const interval = setInterval(() => {
        percent += 5;
        if(bar) bar.style.width = percent + '%';
        if(txt) txt.innerText = percent + '%';
        if(percent >= 100){
          clearInterval(interval);
          localStorage.setItem('lastAttackTime', now);
          showSimplePopup('Attack Berhasil Dikirim!');
          setTimeout(() => {
            if(overlay) overlay.classList.remove('active');
            if(resultModal) resultModal.classList.remove('active');
            if(bar) bar.style.width = '0%';
            if(txt) txt.innerText = '0%';
          }, 1500);
        }
      }, 100);
    }, 2000);
  });
}

/* ---------- Auto Login Check ---------- */
function checkSavedSession(){
  const savedUser = localStorage.getItem('currentUser');
  if(savedUser){
    try{
      currentUser = JSON.parse(savedUser);
      if(currentUser && currentUser.username === VALID_USER){
        document.getElementById('loginWrapper').classList.add('hide');
        document.getElementById('dashboardWrapper').classList.add('show');
        updateDashboardWithUser();
      } else {
        localStorage.removeItem('currentUser');
      }
    } catch(e){ localStorage.removeItem('currentUser'); }
  }
}

checkSavedSession();